<?php
ob_start();
session_start();
session_destroy();
include('location: login.php');
 exit(); 

?>