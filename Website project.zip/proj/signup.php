




<!DOCTYPE html>
<html>
<head>
<title>Signup </title>
<!-- Include CSS file here -->
<link href="css/style.css" rel="stylesheet">
</head>
<body>

<div class="bgimg-1">
  <div class="caption">


  <form class="signup" action="signup2.php" method="post">
 <h3>Sign Up</h3>

    <label for="fname">First Name</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name..">

    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="lastname" placeholder="Your last name..">

	<label for="email">E-mail</label>
    <input type="text" id="email" name="email" placeholder="Your email address..">

	<label for="phone">Phone Number</label>
    <input type="number" id="phone" name="phone" placeholder="Your phone number..">

	<label for="address">Address</label>
	<input type="text" id="address" name="address" placeholder="Enter your address..">


	<label for="pass">Password</label>
    <input type="text" id="pass" name="pass" placeholder="Enter password..">

		<label for="repass">Re-Enter Password</label>
    <input type="text" id="repass" name="repass" placeholder="Re-Enter psassword..">
<br></br>


  
    <input type="submit" value="Sign Up">
  </form>
    </div>
</div>



</body>
</html>