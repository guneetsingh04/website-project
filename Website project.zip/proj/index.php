<!DOCTYPE html>
<html>
<head>
<title>Quiz</title>
<!-- Include CSS file here -->
<link href="css/main.css" rel="stylesheet">
</head>
<body>

<div class="bgimg-1">
  <div class="caption">
<a href="signup.php"><button class="button" style="vertical-align:middle"><span>Sign Up </span></button></a>
<a href="signin.php"><button class="button" style="vertical-align:middle"><span>Sign In </span></button></a>

  </div>
</div>






</body>
</html>