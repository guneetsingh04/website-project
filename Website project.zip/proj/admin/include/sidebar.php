 <aside>
          <div id="sidebar"  class="nav-collapse ">
            
              <ul class="sidebar-menu" id="nav-accordion">
              
              	 
              	  	
                  <li class="mt">
                      <a  href="index.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Dashboard</span>
                      </a>
                  </li>

                  <li class="sub-menu">
                      <a href="users.php" >
                          <i class="fa fa-desktop"></i>
                          <span>Users</span>
                      </a>
                     
                  </li>

                  <li class="sub-menu">
                      <a href="addQuestion.php" >
                          <i class="fa fa-cogs"></i>
                          <span>Add Question</span>
                      </a>
                     
                  </li>
                  <li class="sub-menu">
                      <a href="questions.php" >
                          <i class="fa fa-book"></i>
                          <span>Questions</span>
                      </a>
                      
                  </li>
		   <li class="sub-menu">
                      <a href="addtest.php" >
                          <i class="fa fa-book"></i>
                          <span>Add Test</span>
                      </a>
                      
                  </li>
		   </li>
		   <li class="sub-menu">
                      <a href="changetest.php" >
                          <i class="fa fa-book"></i>
                          <span>Change Tests</span>
                      </a>
                      
                  </li>

              </ul>
             
          </div>
      </aside>